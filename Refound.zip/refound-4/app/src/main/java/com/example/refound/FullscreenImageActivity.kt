package com.example.refound

import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.davemorrissey.labs.subscaleview.ImageSource
import com.davemorrissey.labs.subscaleview.SubsamplingScaleImageView
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

class FullscreenImageActivity : AppCompatActivity() {

    private lateinit var fullscreenImageView: SubsamplingScaleImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fullscreen_image)

        fullscreenImageView = findViewById(R.id.fullscreenImageView)
        val imageUri = intent.getStringExtra("imageUri")

        imageUri?.let {
            loadImage(it)
        }

        fullscreenImageView.setOnClickListener {
            finish() // Close the fullscreen activity when the image is clicked
        }
    }

    private fun loadImage(imageUri: String) {
        // Load image asynchronously
        Thread {
            try {
                val url = URL(imageUri)
                val connection = url.openConnection() as HttpURLConnection
                connection.doInput = true
                connection.connect()
                val inputStream: InputStream = connection.inputStream
                val bitmap = BitmapFactory.decodeStream(inputStream)

                runOnUiThread {
                    fullscreenImageView.setImage(ImageSource.bitmap(bitmap))
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }.start()
    }
}
