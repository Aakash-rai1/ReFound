package com.example.refound

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.*
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.tasks.Task
import com.google.android.gms.tasks.Tasks
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.squareup.picasso.Picasso
import java.util.*

class AddProductActivity : AppCompatActivity() {

    private lateinit var inputName: EditText
    private lateinit var inputPrice: EditText
    private lateinit var inputDesc: EditText
    private lateinit var inputLocation: EditText
    private lateinit var postBtn: Button
    private lateinit var selectImagesBtn: Button
    private lateinit var productImageView: ImageView
    private lateinit var imageRecyclerView: RecyclerView

    private lateinit var imageAdapter: ImageAdapter
    private val imageUris: MutableList<Uri> = ArrayList()
    private var coverImageUri: Uri? = null

    private lateinit var pickImageLauncher: ActivityResultLauncher<String>
    private lateinit var pickImagesLauncher: ActivityResultLauncher<String>

    private lateinit var firebaseAuth: FirebaseAuth
    private val storageReference = FirebaseStorage.getInstance().reference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_product)

        inputName = findViewById(R.id.inputName)
        inputPrice = findViewById(R.id.inputPrice)
        inputDesc = findViewById(R.id.inputDesc)
        inputLocation = findViewById(R.id.inputLocation)
        postBtn = findViewById(R.id.postBtn)
        selectImagesBtn = findViewById(R.id.selectImagesBtn)
        productImageView = findViewById(R.id.productImageView)
        imageRecyclerView = findViewById(R.id.imageRecyclerView)

        firebaseAuth = FirebaseAuth.getInstance()

        // Set up RecyclerView
        imageAdapter = ImageAdapter(imageUris)
        imageRecyclerView.adapter = imageAdapter
        imageRecyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)

        // Initialize ActivityResultLauncher for picking a single image (cover image)
        pickImageLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            uri?.let {
                coverImageUri = it
                Picasso.get().load(it).into(productImageView)
            }
        }

        // Initialize ActivityResultLauncher for picking multiple images
        pickImagesLauncher = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
            uris?.let {
                imageUris.clear()
                imageUris.addAll(uris)
                imageAdapter.notifyDataSetChanged()
            }
        }

        // Handle cover image selection
        productImageView.setOnClickListener {
            pickImageLauncher.launch("image/*")
        }

        // Handle additional image selection
        selectImagesBtn.setOnClickListener {
            pickImagesLauncher.launch("image/*")
        }

        // Handle posting the product
        postBtn.setOnClickListener {
            uploadFiles()
        }
    }

    private fun uploadFiles() {
        if (coverImageUri != null || imageUris.isNotEmpty()) {
            val uploadTasks = mutableListOf<Task<Uri>>()
            val downloadUrls = mutableListOf<String>()

            // Upload cover image if available
            coverImageUri?.let { uri ->
                val coverImageRef = storageReference.child("products/${System.currentTimeMillis()}_cover.jpg")
                uploadTasks.add(coverImageRef.putFile(uri).continueWithTask { task ->
                    if (!task.isSuccessful) {
                        Log.e("UploadError", "Cover image upload failed", task.exception)
                        throw task.exception ?: Exception("Unknown error")
                    }
                    coverImageRef.downloadUrl
                }.addOnSuccessListener { uri ->
                    downloadUrls.add(uri.toString())
                })
            }

            // Upload additional images
            imageUris.forEach { uri ->
                val imageRef = storageReference.child("products/${System.currentTimeMillis()}.jpg")
                uploadTasks.add(imageRef.putFile(uri).continueWithTask { task ->
                    if (!task.isSuccessful) {
                        Log.e("UploadError", "Additional image upload failed", task.exception)
                        throw task.exception ?: Exception("Unknown error")
                    }
                    imageRef.downloadUrl
                }.addOnSuccessListener { uri ->
                    downloadUrls.add(uri.toString())
                })
            }

            // Wait for all uploads to complete
            Tasks.whenAllComplete(uploadTasks).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val coverImageUrl = downloadUrls.firstOrNull { url ->
                        url.contains("_cover.jpg") // Identify cover image URL
                    } ?: ""

                    // Remaining URLs are for description images
                    val descriptionImages = downloadUrls.filter { url ->
                        !url.contains("_cover.jpg") // Filter out cover image URL
                    }

                    val productName = inputName.text.toString().trim()
                    val productPrice = inputPrice.text.toString().trim().toDoubleOrNull() ?: 0.0
                    val productDesc = inputDesc.text.toString().trim()
                    val productLocation = inputLocation.text.toString().trim()
                    val uploadedBy = firebaseAuth.currentUser?.email ?: "Unknown"

                    val product = Product(
                        productName,
                        productPrice,
                        coverImageUrl,
                        productLocation,
                        productDesc,
                        uploadedBy,
                        descriptionImages = descriptionImages
                    )

                    val databaseReference = FirebaseDatabase.getInstance().getReference("Products")
                    val productId = databaseReference.push().key
                    if (productId != null) {
                        databaseReference.child(productId).setValue(product)
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    Toast.makeText(this, "Product added successfully", Toast.LENGTH_SHORT).show()
                                    finish()
                                } else {
                                    Log.e("DatabaseError", "Failed to add product", task.exception)
                                    Toast.makeText(this, "Failed to add product", Toast.LENGTH_SHORT).show()
                                }
                            }
                    }
                } else {
                    Log.e("UploadError", "Failed to upload images", task.exception)
                    Toast.makeText(this, "Failed to upload images", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            Toast.makeText(this, "No images selected", Toast.LENGTH_SHORT).show()
        }
    }
}
