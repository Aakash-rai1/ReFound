package com.example.refound

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.firebase.ui.database.FirebaseRecyclerAdapter
import com.firebase.ui.database.FirebaseRecyclerOptions
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference

class MyProductAdapter(options: FirebaseRecyclerOptions<Product>) :
    FirebaseRecyclerAdapter<Product, MyProductAdapter.ProductViewHolder>(options) {

    class ProductViewHolder(inflater: LayoutInflater, parent: ViewGroup) :
        RecyclerView.ViewHolder(inflater.inflate(R.layout.myproductcard, parent, false)) {
        val pName: TextView = itemView.findViewById(R.id.productName)
        val pPrice: TextView = itemView.findViewById(R.id.productPrice)
        val pImage: ImageView = itemView.findViewById(R.id.productImage)
        val editButton: Button = itemView.findViewById(R.id.edit_button)
        val deleteButton: Button = itemView.findViewById(R.id.delete_button)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return ProductViewHolder(inflater, parent)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int, model: Product) {
        val storageRef: StorageReference = FirebaseStorage.getInstance().getReferenceFromUrl(model.productImage)

        Glide.with(holder.pImage.context).load(storageRef).into(holder.pImage)

        holder.pName.text = model.productName
        holder.pPrice.text = "$${model.productPrice}"

        holder.itemView.setOnClickListener {
            val intent = Intent(holder.itemView.context, ProductDetailsActivity::class.java)
            intent.putExtra("product", model)
            holder.itemView.context.startActivity(intent)
        }

        // Handle edit button click
        holder.editButton.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, EditProductActivity::class.java)
            intent.putExtra("productKey", getRef(position).key)
            context.startActivity(intent)
        }

        // Handle delete button click
        holder.deleteButton.setOnClickListener {
            getRef(position).removeValue()
        }
    }
}
