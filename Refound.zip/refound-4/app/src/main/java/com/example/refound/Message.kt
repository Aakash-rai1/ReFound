// Message.kt
package com.example.refound

data class Message(val userName: String, val messageText: String)
