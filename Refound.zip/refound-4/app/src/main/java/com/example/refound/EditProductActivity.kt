//package com.example.refound
//
//import android.os.Bundle
//import android.widget.Button
//import android.widget.EditText
//import androidx.appcompat.app.AppCompatActivity
//import com.google.firebase.database.FirebaseDatabase
//
//class EditProductActivity : AppCompatActivity() {
//
//    private lateinit var productNameEditText: EditText
//    private lateinit var productPriceEditText: EditText
//    private lateinit var productLocationEditText: EditText
//    private lateinit var productDescEditText: EditText
//    private lateinit var saveButton: Button
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_edit_product)
//
//        productNameEditText = findViewById(R.id.edit_product_name)
//        productPriceEditText = findViewById(R.id.edit_product_price)
//        productLocationEditText = findViewById(R.id.edit_product_location)
//        productDescEditText = findViewById(R.id.edit_product_desc)
//        saveButton = findViewById(R.id.save_button)
//
//        val productKey = intent.getStringExtra("productKey")
//        val databaseRef = FirebaseDatabase.getInstance().getReference("Products").child(productKey!!)
//
//        // Load existing product data
//        databaseRef.get().addOnSuccessListener { dataSnapshot ->
//            val product = dataSnapshot.getValue(Product::class.java)
//            product?.let {
//                productNameEditText.setText(it.productName)
//                productPriceEditText.setText(it.productPrice.toString())
//                productLocationEditText.setText(it.productLocation)
//                productDescEditText.setText(it.productDesc)
//            }
//        }
//
//        // Save updated product data
//        saveButton.setOnClickListener {
//            val updatedProductName = productNameEditText.text.toString()
//            val updatedProductPrice = productPriceEditText.text.toString().toDouble()
//            val updatedProductLocation = productLocationEditText.text.toString()
//            val updatedProductDesc = productDescEditText.text.toString()
//
//            val productUpdates = mapOf<String, Any>(
//                "productName" to updatedProductName,
//                "productPrice" to updatedProductPrice,
//                "productLocation" to updatedProductLocation,
//                "productDesc" to updatedProductDesc
//            )
//
//            databaseRef.updateChildren(productUpdates).addOnCompleteListener { task ->
//                if (task.isSuccessful) {
//                    finish() // Close the activity after successful update
//                }
//            }
//        }
//    }
//}
package com.example.refound

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase

class EditProductActivity : AppCompatActivity() {

    private lateinit var productNameEditText: EditText
    private lateinit var productPriceEditText: EditText
    private lateinit var productLocationEditText: EditText
    private lateinit var productDescEditText: EditText
    private lateinit var saveButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_product)

        productNameEditText = findViewById(R.id.edit_product_name)
        productPriceEditText = findViewById(R.id.edit_product_price)
        productLocationEditText = findViewById(R.id.edit_product_location)
        productDescEditText = findViewById(R.id.edit_product_desc)
        saveButton = findViewById(R.id.save_button)

        val productKey = intent.getStringExtra("productKey")
        val databaseRef = FirebaseDatabase.getInstance().getReference("Products").child(productKey!!)

        // Load existing product data
        databaseRef.get().addOnSuccessListener { dataSnapshot ->
            val product = dataSnapshot.getValue(Product::class.java)
            product?.let {
                productNameEditText.setText(it.productName)
                productPriceEditText.setText(it.productPrice.toString())
                productLocationEditText.setText(it.productLocation)
                productDescEditText.setText(it.productDesc)
            }
        }

        // Save updated product data
        saveButton.setOnClickListener {
            val updatedProductName = productNameEditText.text.toString()
            val updatedProductPrice = productPriceEditText.text.toString().toDouble()
            val updatedProductLocation = productLocationEditText.text.toString()
            val updatedProductDesc = productDescEditText.text.toString()

            val productUpdates = mapOf<String, Any>(
                "productName" to updatedProductName,
                "productPrice" to updatedProductPrice,
                "productLocation" to updatedProductLocation,
                "productDesc" to updatedProductDesc
            )

            databaseRef.updateChildren(productUpdates).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    val intent = Intent(this, MyProductsActivity::class.java)
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(intent)
                    finish() // Close the activity after successful update
                }
            }
        }
    }
}
