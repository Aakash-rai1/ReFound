package com.example.refound

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class ChatActivity : AppCompatActivity() {

    private lateinit var chatRecyclerView: RecyclerView
    private lateinit var messageEditText: EditText
    private lateinit var sendButton: Button

    private val messages = mutableListOf<Message>()
    private lateinit var chatAdapter: ChatAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            setContentView(R.layout.activity_chat)

            chatRecyclerView = findViewById(R.id.chatRecyclerView)
            messageEditText = findViewById(R.id.messageEditText)
            sendButton = findViewById(R.id.sendButton)

            chatAdapter = ChatAdapter(messages)
            chatRecyclerView.layoutManager = LinearLayoutManager(this)
            chatRecyclerView.adapter = chatAdapter

            sendButton.setOnClickListener {
                val messageText = messageEditText.text.toString().trim()
                if (messageText.isNotEmpty()) {
                    // Add message to the list and notify the adapter
                    messages.add(Message("User", messageText))
                    chatAdapter.notifyItemInserted(messages.size - 1)
                    messageEditText.text.clear()
                    chatRecyclerView.smoothScrollToPosition(messages.size - 1)
                } else {
                    Toast.makeText(this, "Message cannot be empty", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            Log.e("ChatActivity", "Error initializing ChatActivity", e)
        }
    }
}
