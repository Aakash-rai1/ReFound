import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.refound.Product
import com.example.refound.ProductDetailsActivity
import com.example.refound.R
import com.firebase.ui.database.FirebaseRecyclerAdapter
import com.firebase.ui.database.FirebaseRecyclerOptions

class ProductAdapter(options: FirebaseRecyclerOptions<Product>) :
    FirebaseRecyclerAdapter<Product, ProductAdapter.ProductViewHolder>(options) {

    class ProductViewHolder(inflater: LayoutInflater, parent: ViewGroup) :
        RecyclerView.ViewHolder(inflater.inflate(R.layout.productcard, parent, false)) {
        val pName: TextView = itemView.findViewById(R.id.productName)
        val pLocation: TextView = itemView.findViewById(R.id.productLocation)
        val pImage: ImageView = itemView.findViewById(R.id.productImage)
        val pPrice: TextView = itemView.findViewById(R.id.productPrice)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return ProductViewHolder(inflater, parent)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int, model: Product) {
        Glide.with(holder.pImage.context)
            .load(model.productImage)
            .into(holder.pImage)

        holder.pName.text = model.productName
        holder.pLocation.text = model.productLocation
        holder.pPrice.text = "$${model.productPrice}"

        holder.itemView.setOnClickListener {
            val intent = Intent(holder.itemView.context, ProductDetailsActivity::class.java)
            intent.putExtra("product", model)
            holder.itemView.context.startActivity(intent)
        }
    }
}
