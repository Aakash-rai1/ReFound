//    package com.example.refound
//
//    import ProductAdapter
//    import android.os.Bundle
//    import android.widget.Toast
//    import androidx.appcompat.app.AppCompatActivity
//    import androidx.recyclerview.widget.LinearLayoutManager
//    import androidx.recyclerview.widget.RecyclerView
//    import com.firebase.ui.database.FirebaseRecyclerOptions
//    import com.google.firebase.auth.FirebaseAuth
//    import com.google.firebase.database.FirebaseDatabase
//
//    class wishlist : AppCompatActivity() {
//
//        private lateinit var recyclerView: RecyclerView
//        private lateinit var adapter: ProductAdapter
//        private lateinit var auth: FirebaseAuth
//        private lateinit var database: FirebaseDatabase
//
//        override fun onCreate(savedInstanceState: Bundle?) {
//            super.onCreate(savedInstanceState)
//            setContentView(R.layout.activity_wishlist)
//
//            recyclerView = findViewById(R.id.recyclerview)
//            recyclerView.layoutManager = LinearLayoutManager(this)
//
//            auth = FirebaseAuth.getInstance()
//            database = FirebaseDatabase.getInstance()
//
//            val userId = auth.currentUser?.uid
//            userId?.let {
//                val query = database.reference.child("Wishlist").child(userId)
//                    .orderByChild("addedAt")
//
//                val options = FirebaseRecyclerOptions.Builder<Product>()
//                    .setQuery(query, Product::class.java)
//                    .build()
//
//                adapter = ProductAdapter(options)
//                recyclerView.adapter = adapter
//            } ?: run {
//                Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
//            }
//        }
//
//        override fun onStart() {
//            super.onStart()
//            adapter.startListening()
//        }
//
//        override fun onStop() {
//            super.onStop()
//            adapter.stopListening()
//        }
//    }
package com.example.refound

import ProductAdapter
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.firebase.ui.database.FirebaseRecyclerOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class wishlist : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ProductAdapter
    private lateinit var auth: FirebaseAuth
    private lateinit var database: FirebaseDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_wishlist)

        // Initialize Toolbar
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        // Set the title of the toolbar explicitly
        supportActionBar?.title = null // Or set a custom title here if needed

        // Enable the back button
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Set up RecyclerView
        recyclerView = findViewById(R.id.recyclerview)
        recyclerView.layoutManager = LinearLayoutManager(this)

        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance()

        val userId = auth.currentUser?.uid
        userId?.let {
            val query = database.reference.child("Wishlist").child(userId)
                .orderByChild("addedAt")

            val options = FirebaseRecyclerOptions.Builder<Product>()
                .setQuery(query, Product::class.java)
                .build()

            adapter = ProductAdapter(options)
            recyclerView.adapter = adapter
        } ?: run {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onStart() {
        super.onStart()
        adapter.startListening()
    }

    override fun onStop() {
        super.onStop()
        adapter.stopListening()
    }

    override fun onOptionsItemSelected(item: android.view.MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                // Handle the back button click
                onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}
