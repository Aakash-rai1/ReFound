
//
//package com.example.refound
//
//import android.content.Intent
//import android.location.Address
//import android.location.Geocoder
//import android.net.Uri
//import android.os.Bundle
//import android.util.Log
//import android.widget.Button
//import android.widget.ImageView
//import android.widget.TextView
//import android.widget.Toast
//import androidx.appcompat.app.AppCompatActivity
//import androidx.recyclerview.widget.LinearLayoutManager
//import androidx.recyclerview.widget.RecyclerView
//import com.bumptech.glide.Glide
//import com.google.android.gms.maps.CameraUpdateFactory
//import com.google.android.gms.maps.GoogleMap
//import com.google.android.gms.maps.MapView
//import com.google.android.gms.maps.OnMapReadyCallback
//import com.google.android.gms.maps.model.LatLng
//import com.google.android.gms.maps.model.MarkerOptions
//import com.google.firebase.auth.FirebaseAuth
//import com.google.firebase.database.DatabaseReference
//import com.google.firebase.database.FirebaseDatabase
//import java.util.*
//
//class ProductDetailsActivity : AppCompatActivity(), OnMapReadyCallback {
//
//    private lateinit var productDetailImage: ImageView
//    private lateinit var productDetailName: TextView
//    private lateinit var productDetailPrice: TextView
//    private lateinit var productDetailLocation: TextView
//    private lateinit var productDetailDesc: TextView
//    private lateinit var productDetailUploadedBy: TextView
//    private lateinit var mapView: MapView
//    private lateinit var googleMap: GoogleMap
//    private lateinit var imageRecyclerView: RecyclerView
//    private lateinit var imageAdapter: ImageAdapter
//    private lateinit var wishlistButton: Button
//    private val MAP_VIEW_BUNDLE_KEY = "MapViewBundleKey"
//    private lateinit var database: DatabaseReference
//    private lateinit var auth: FirebaseAuth
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_product_details)
//
//        productDetailImage = findViewById(R.id.productDetailImage)
//        productDetailName = findViewById(R.id.productDetailName)
//        productDetailPrice = findViewById(R.id.productDetailPrice)
//        productDetailLocation = findViewById(R.id.productDetailLocation)
//        productDetailDesc = findViewById(R.id.productDetailDesc)
//        productDetailUploadedBy = findViewById(R.id.productDetailUploadedBy)
//        mapView = findViewById(R.id.mapView)
//        imageRecyclerView = findViewById(R.id.imageRecyclerView)
//        wishlistButton = findViewById(R.id.addToWishlistButton)
//
//        database = FirebaseDatabase.getInstance().reference
//        auth = FirebaseAuth.getInstance()
//
//        val product = intent.getParcelableExtra<Product>("product")
//
//        product?.let {
//            Glide.with(this).load(it.productImage).into(productDetailImage)
//            productDetailName.text = it.productName
//            productDetailPrice.text = "$${it.productPrice}"
//            productDetailLocation.text = it.productLocation
//            productDetailDesc.text = it.productDesc
//            productDetailUploadedBy.text = "Uploaded by: ${it.uploadedBy}"
//
//            val imageUris = it.descriptionImages.map { url -> Uri.parse(url) }
//            imageAdapter = ImageAdapter(imageUris)
//            imageRecyclerView.adapter = imageAdapter
//            imageRecyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
//
//            // Check if the product is already in the wishlist
//            val userId = auth.currentUser?.uid ?: return
//            val productRef = database.child("Wishlist").child(userId).child(it.productName)
//            productRef.get().addOnSuccessListener { snapshot ->
//                if (snapshot.exists()) {
//                    wishlistButton.text = "Remove from Wishlist"
//                } else {
//                    wishlistButton.text = "Add to Wishlist"
//                }
//            }
//
//            wishlistButton.setOnClickListener {
//                product?.let { product ->
//                    handleWishlistButtonClick(product)
//                }            }
//        }
//
//        var mapViewBundle: Bundle? = null
//        if (savedInstanceState != null) {
//            mapViewBundle = savedInstanceState.getBundle(MAP_VIEW_BUNDLE_KEY)
//        }
//        mapView.onCreate(mapViewBundle)
//        mapView.getMapAsync(this)
//
//        productDetailImage.setOnClickListener {
//            val intent = Intent(this, FullscreenImageActivity::class.java).apply {
//                putExtra("imageUri", product?.productImage)
//            }
//            startActivity(intent)
//        }
//    }
//
//    private fun handleWishlistButtonClick(product: Product) {
//        val userId = auth.currentUser?.uid ?: return
//        val productRef = database.child("Wishlist").child(userId).child(product.productName)
//        productRef.get().addOnSuccessListener { snapshot ->
//            if (snapshot.exists()) {
//                // Product is already in the wishlist, so remove it
//                productRef.removeValue().addOnSuccessListener {
//                    Toast.makeText(this, "Removed from Wishlist", Toast.LENGTH_SHORT).show()
//                    wishlistButton.text = "Add to Wishlist"
//                }
//            } else {
//                // Product is not in the wishlist, so add it
//                productRef.setValue(product).addOnSuccessListener {
//                    Toast.makeText(this, "Added to Wishlist", Toast.LENGTH_SHORT).show()
//                    wishlistButton.text = "Remove from Wishlist"
//                }
//            }
//        }
//    }
//
//    override fun onSaveInstanceState(outState: Bundle) {
//        super.onSaveInstanceState(outState)
//        var mapViewBundle = outState.getBundle(MAP_VIEW_BUNDLE_KEY)
//        if (mapViewBundle == null) {
//            mapViewBundle = Bundle()
//            outState.putBundle(MAP_VIEW_BUNDLE_KEY, mapViewBundle)
//        }
//        mapView.onSaveInstanceState(mapViewBundle)
//    }
//
//    override fun onResume() {
//        super.onResume()
//        mapView.onResume()
//    }
//
//    override fun onStart() {
//        super.onStart()
//        mapView.onStart()
//    }
//
//    override fun onStop() {
//        super.onStop()
//        mapView.onStop()
//    }
//
//    override fun onPause() {
//        mapView.onPause()
//        super.onPause()
//    }
//
//    override fun onDestroy() {
//        mapView.onDestroy()
//        super.onDestroy()
//    }
//
//    override fun onLowMemory() {
//        super.onLowMemory()
//        mapView.onLowMemory()
//    }
//
//    override fun onMapReady(map: GoogleMap) {
//        googleMap = map
//        Log.d("Map", "Map is ready")
//
//        val product = intent.getParcelableExtra<Product>("product")
//        product?.let {
//            val geocoder = Geocoder(this)
//            val addressList: List<Address>? = geocoder.getFromLocationName(it.productLocation, 1)
//
//            Log.d("Geocoder", "Address List: $addressList")
//
//            if (!addressList.isNullOrEmpty()) {
//                val address = addressList[0]
//                val latLng = LatLng(address.latitude, address.longitude)
//                Log.d("Map", "LatLng: $latLng")
//                googleMap.addMarker(MarkerOptions().position(latLng).title(it.productLocation))
//                googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15f))
//            } else {
//                Toast.makeText(this, "Location not found", Toast.LENGTH_SHORT).show()
//            }
//        }
//    }
//}

package com.example.refound

import android.content.Intent
import android.graphics.Color
import android.location.Address
import android.location.Geocoder
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import java.util.*

class ProductDetailsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var productDetailImage: ImageView
    private lateinit var productDetailName: TextView
    private lateinit var productDetailPrice: TextView
    private lateinit var productDetailLocation: TextView
    private lateinit var productDetailDesc: TextView
    private lateinit var productDetailUploadedBy: TextView
    private lateinit var mapView: MapView
    private lateinit var googleMap: GoogleMap
    private lateinit var imageRecyclerView: RecyclerView
    private lateinit var imageAdapter: ImageAdapter
    private lateinit var addToWishlistButton: Button
    private val MAP_VIEW_BUNDLE_KEY = "MapViewBundleKey"
    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth
    //private lateinit var currentUserId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_details)

        productDetailImage = findViewById(R.id.productDetailImage)
        productDetailName = findViewById(R.id.productDetailName)
        productDetailPrice = findViewById(R.id.productDetailPrice)
        productDetailLocation = findViewById(R.id.productDetailLocation)
        productDetailDesc = findViewById(R.id.productDetailDesc)
        productDetailUploadedBy = findViewById(R.id.productDetailUploadedBy)
        mapView = findViewById(R.id.mapView)
        imageRecyclerView = findViewById(R.id.imageRecyclerView)
        addToWishlistButton = findViewById(R.id.addToWishlistButton)
        val chatWithOwnerButton: Button = findViewById(R.id.chatButton)

        database = FirebaseDatabase.getInstance().reference
        auth = FirebaseAuth.getInstance()

        val product = intent.getParcelableExtra<Product>("product")
        val userId = auth.currentUser?.uid ?: return
        val productKey = product?.productName ?: return
        val wishlistRef = database.child("Wishlist").child(userId).child(productKey)

        // Check if the product is already in the wishlist
        wishlistRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                if (dataSnapshot.exists()) {
                    // Product is in the wishlist
                    addToWishlistButton.text = "Remove from Wishlist"
                    addToWishlistButton.setBackgroundColor(resources.getColor(R.color.colorRemoveFromWishlist, null))
                } else {
                    // Product is not in the wishlist
                    addToWishlistButton.text = "Add to Wishlist"
                    addToWishlistButton.setBackgroundColor(resources.getColor(R.color.colorAddToWishlist, null))
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Toast.makeText(this@ProductDetailsActivity, "Error checking wishlist status", Toast.LENGTH_SHORT).show()
            }
        })

        addToWishlistButton.setOnClickListener {
            product?.let {
                wishlistRef.addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(dataSnapshot: DataSnapshot) {
                        if (dataSnapshot.exists()) {
                            // Remove from wishlist
                            wishlistRef.removeValue()
                                .addOnSuccessListener {
                                    Toast.makeText(this@ProductDetailsActivity, "Removed from Wishlist", Toast.LENGTH_SHORT).show()
                                    addToWishlistButton.text = "Add to Wishlist"
                                    addToWishlistButton.setBackgroundColor(resources.getColor(R.color.colorAddToWishlist, null))
                                }
                                .addOnFailureListener {
                                    Toast.makeText(this@ProductDetailsActivity, "Failed to Remove from Wishlist", Toast.LENGTH_SHORT).show()
                                }
                        } else {
                            // Add to wishlist
                            wishlistRef.setValue(it)
                                .addOnSuccessListener {
                                    Toast.makeText(this@ProductDetailsActivity, "Added to Wishlist", Toast.LENGTH_SHORT).show()
                                    addToWishlistButton.text = "Remove from Wishlist"
                                    addToWishlistButton.setBackgroundColor(resources.getColor(R.color.colorRemoveFromWishlist, null))
                                }
                                .addOnFailureListener {
                                    Toast.makeText(this@ProductDetailsActivity, "Failed to Add to Wishlist", Toast.LENGTH_SHORT).show()
                                }
                        }
                    }

                    override fun onCancelled(databaseError: DatabaseError) {
                        Toast.makeText(this@ProductDetailsActivity, "Error updating wishlist", Toast.LENGTH_SHORT).show()
                    }
                })
            }
        }

        var mapViewBundle: Bundle? = null
        if (savedInstanceState != null) {
            mapViewBundle = savedInstanceState.getBundle(MAP_VIEW_BUNDLE_KEY)
        }
        mapView.onCreate(mapViewBundle)
        mapView.getMapAsync(this)

        product?.let {
            Glide.with(this).load(it.productImage).into(productDetailImage)
            productDetailName.text = it.productName
            productDetailPrice.text = "$${it.productPrice}"
            productDetailLocation.text = it.productLocation
            productDetailDesc.text = it.productDesc
            productDetailUploadedBy.text = "Uploaded by: ${it.uploadedBy}"

            val imageUris = it.descriptionImages.map { url -> Uri.parse(url) }
            imageAdapter = ImageAdapter(imageUris)
            imageRecyclerView.adapter = imageAdapter
            imageRecyclerView.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        }

        chatWithOwnerButton.setOnClickListener {
            val uploaderId = product?.uploadedBy ?: ""
            val intent = Intent(this, ChatActivity::class.java).apply {
               // putExtra("CURRENT_USER_ID", currentUserId)
                putExtra("OWNER_ID", uploaderId)
            }
            startActivity(intent)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        var mapViewBundle = outState.getBundle(MAP_VIEW_BUNDLE_KEY)
        if (mapViewBundle == null) {
            mapViewBundle = Bundle()
            outState.putBundle(MAP_VIEW_BUNDLE_KEY, mapViewBundle)
        }
        mapView.onSaveInstanceState(mapViewBundle)
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
    }

    override fun onStart() {
        super.onStart()
        mapView.onStart()
    }

    override fun onStop() {
        super.onStop()
        mapView.onStop()
    }

    override fun onPause() {
        mapView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        mapView.onDestroy()
        super.onDestroy()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        mapView.onLowMemory()
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map
        Log.d("Map", "Map is ready")

        val product = intent.getParcelableExtra<Product>("product")
        product?.let {
            val geocoder = Geocoder(this)
            val addressList: List<Address>? = geocoder.getFromLocationName(it.productLocation, 1)

            Log.d("Geocoder", "Address List: $addressList")

            if (!addressList.isNullOrEmpty()) {
                val address = addressList[0]
                val latLng = LatLng(address.latitude, address.longitude)
                Log.d("Map", "LatLng: $latLng")
                googleMap.addMarker(MarkerOptions().position(latLng).title(it.productLocation))
                googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15f))
            } else {
                Toast.makeText(this, "Location not found", Toast.LENGTH_SHORT).show()
            }
        }
    }
}


