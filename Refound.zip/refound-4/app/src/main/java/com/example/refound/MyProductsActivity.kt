//package com.example.refound
//
//import android.os.Bundle
//import androidx.activity.enableEdgeToEdge
//import androidx.appcompat.app.AppCompatActivity
//import androidx.recyclerview.widget.LinearLayoutManager
//import androidx.recyclerview.widget.RecyclerView
//import com.example.refound.databinding.ActivityMyProductsBinding
//import com.firebase.ui.database.FirebaseRecyclerOptions
//import com.google.firebase.auth.FirebaseAuth
//import com.google.firebase.database.FirebaseDatabase
//
//class MyProductsActivity : AppCompatActivity() {
//
//    private lateinit var binding: ActivityMyProductsBinding
//    private lateinit var firebaseAuth: FirebaseAuth
//    lateinit var adapter: MyProductAdapter
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        binding = ActivityMyProductsBinding.inflate(layoutInflater)
//        setContentView(binding.root)
//
//        enableEdgeToEdge()
//
//        firebaseAuth = FirebaseAuth.getInstance()
//
//        setupRecyclerView()
//        fetchProducts()
//    }
//
//    private fun setupRecyclerView() {
//        val recyclerView: RecyclerView = binding.recyclerview
//        recyclerView.layoutManager = LinearLayoutManager(this)
//    }
//
//    private fun fetchProducts() {
//        val currentUser = firebaseAuth.currentUser
//        currentUser?.let {
//            val userEmail = it.email
//            userEmail?.let {
//                val query = FirebaseDatabase.getInstance().reference.child("Products").orderByChild("uploadedBy").equalTo(userEmail)
//                val options = FirebaseRecyclerOptions.Builder<Product>()
//                    .setQuery(query, Product::class.java)
//                    .build()
//
//                adapter = MyProductAdapter(options)
//                binding.recyclerview.adapter = adapter
//            }
//        }
//    }
//
//    override fun onStart() {
//        super.onStart()
//        adapter.startListening()
//    }
//
//    override fun onStop() {
//        super.onStop()
//        adapter.stopListening()
//    }
//}

package com.example.refound

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.refound.databinding.ActivityMyProductsBinding
import com.firebase.ui.database.FirebaseRecyclerOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class MyProductsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMyProductsBinding
    private lateinit var drawerToggle: ActionBarDrawerToggle
    private lateinit var firebaseAuth: FirebaseAuth
    lateinit var adapter: MyProductAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMyProductsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()

        setSupportActionBar(binding.toolbar)

        drawerToggle = ActionBarDrawerToggle(
            this,
            binding.drawerLayout,
            binding.toolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )

        binding.drawerLayout.addDrawerListener(drawerToggle)
        drawerToggle.syncState()

        binding.navView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_home -> {
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    binding.drawerLayout.closeDrawers()
                    true
                }
                R.id.nav_profile -> {
                    val intent = Intent(this, ProfileActivity::class.java)
                    startActivity(intent)
                    binding.drawerLayout.closeDrawers()
                    true
                }
                R.id.nav_my_products -> {
                    // If already on this activity, just close the drawer
                    binding.drawerLayout.closeDrawers()
                    true
                }

                R.id.nav_wishlist -> {
                    val intent = Intent(this, wishlist::class.java)
                    startActivity(intent)
                    binding.drawerLayout.closeDrawers()
                    true
                }

                R.id.logout -> {
                    showLogoutConfirmationDialog()
                    true
                }
                else -> false
            }
        }

        setupRecyclerView()
        fetchProducts()
    }

    private fun setupRecyclerView() {
        val recyclerView: RecyclerView = binding.recyclerview
        recyclerView.layoutManager = LinearLayoutManager(this)
    }

    private fun fetchProducts() {
        val currentUser = firebaseAuth.currentUser
        currentUser?.let {
            val userEmail = it.email
            userEmail?.let {
                val query = FirebaseDatabase.getInstance().reference.child("Products").orderByChild("uploadedBy").equalTo(userEmail)
                val options = FirebaseRecyclerOptions.Builder<Product>()
                    .setQuery(query, Product::class.java)
                    .build()

                adapter = MyProductAdapter(options)
                binding.recyclerview.adapter = adapter
            }
        }
    }

    override fun onStart() {
        super.onStart()
        adapter.startListening()
    }

    override fun onStop() {
        super.onStop()
        adapter.stopListening()
    }

    private fun showLogoutConfirmationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Yes") { dialog, which ->
                firebaseAuth.signOut()
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
                finish()
            }
            .setNegativeButton("No") { dialog, which ->
                dialog.dismiss()
            }
            .show()
    }
}
