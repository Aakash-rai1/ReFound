package com.example.refound

data class User (
    var photoUrl: String = "",
    var userName: String = "",
)