package com.example.refound

import android.os.Parcel
import android.os.Parcelable

data class Product(
    var productName: String = "",
    var productPrice: Double = 0.0,
    var productImage: String = "",
    var productLocation: String = "",
    var productDesc: String = "",
    var uploadedBy: String = "", // New field for uploader info
    var descriptionImages: List<String> = emptyList() // New field for description images
) : Parcelable {

    // Constructor used for parceling
    constructor(parcel: Parcel) : this(
        parcel.readString() ?: "",
        parcel.readDouble(),
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "",
        parcel.readString() ?: "", // New field for uploader info
        parcel.createStringArrayList() ?: emptyList() // New field for description images
    )

    // Write object values to parcel for storage
    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(productName)
        parcel.writeDouble(productPrice)
        parcel.writeString(productImage)
        parcel.writeString(productLocation)
        parcel.writeString(productDesc)
        parcel.writeString(uploadedBy) // New field for uploader info
        parcel.writeStringList(descriptionImages) // New field for description images
    }

    // Creator for parcelable
    companion object CREATOR : Parcelable.Creator<Product> {
        override fun createFromParcel(parcel: Parcel): Product {
            return Product(parcel)
        }

        override fun newArray(size: Int): Array<Product?> {
            return arrayOfNulls(size)
        }
    }

    override fun describeContents(): Int {
        return 0
    }
}
