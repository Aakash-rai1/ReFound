package com.example.refound

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.example.refound.databinding.ActivityProfileBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import java.io.ByteArrayOutputStream
import java.util.*

class ProfileActivity : AppCompatActivity() {
    private lateinit var binding: ActivityProfileBinding
    private lateinit var databaseRef: DatabaseReference
    private var cameraLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uniqueID = UUID.randomUUID().toString()
            val photo = result.data?.extras?.get("data") as Bitmap
            uploadPhoto(photo, uniqueID)
        }
    }
    private var galleryLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, uri)
                uploadPhoto(bitmap, UUID.randomUUID().toString())
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize Firebase database reference
        databaseRef = FirebaseDatabase.getInstance().getReference("users")

        // Load user profile UI and data
        loadUI()
        loadUserProfile()

        // Button click to change username
        binding.changenamebtn.setOnClickListener {
            val newUsername = binding.username.text.toString().trim()
            if (newUsername.isNotEmpty()) {
                updateUsername(newUsername)
            } else {
                Toast.makeText(this, "Username cannot be empty", Toast.LENGTH_SHORT).show()
            }
        }

        // Image view click to select image source
        binding.userImage.setOnClickListener {
            showImageSourceDialog()
        }
    }

    private fun uploadPhoto(bmp: Bitmap, id: String) {
        val storageRef = FirebaseStorage.getInstance().getReference(id)
        val baos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos)
        val data = baos.toByteArray()
        val uploadTask = storageRef.putBytes(data)
        uploadTask.addOnFailureListener {
            Log.e("FBError", "Upload failed!")
        }.addOnSuccessListener {
            storageRef.downloadUrl.addOnSuccessListener { uri ->
                val downloadUrl = uri.toString()
                insertDB(downloadUrl)
                loadImageIntoView(downloadUrl)
            }
        }
    }

    private fun insertDB(downloadUrl: String) {
        val userId = FirebaseAuth.getInstance().currentUser?.uid
        val userName = FirebaseAuth.getInstance().currentUser?.displayName ?: "Anonymous"
        val user = User(downloadUrl, userName)
        userId?.let {
            databaseRef.child(it).setValue(user)
        }
    }

    private fun loadImageIntoView(downloadUrl: String?) {
        if (!downloadUrl.isNullOrEmpty()) {
            Glide.with(this)
                .load(downloadUrl)
                .into(binding.userImage)
        } else {
            // Load default image if downloadUrl is null or empty
            Glide.with(this)
                .load(R.drawable.noimg) // Replace with your default image resource
                .into(binding.userImage)
        }
    }

    private fun loadUI() {
        // Load user image and username initially
        loadImageIntoView(null) // Load default image initially
    }

    private fun loadUserProfile() {
        // Load user profile data from Firebase
        val userId = FirebaseAuth.getInstance().currentUser?.uid
        userId?.let {
            databaseRef.child(it).get().addOnSuccessListener { dataSnapshot ->
                val user = dataSnapshot.getValue(User::class.java)
                user?.let {
                    loadImageIntoView(user.photoUrl)
                    binding.showusername.text = user.userName
                }
            }.addOnFailureListener {
                Log.e("DBError", "Failed to load user profile")
            }
        }
    }

    private fun updateUsername(newUsername: String) {
        // Update username in Firebase database
        val userId = FirebaseAuth.getInstance().currentUser?.uid
        userId?.let {
            databaseRef.child(it).child("userName").setValue(newUsername)
                .addOnSuccessListener {
                    binding.showusername.text = newUsername
                    Log.d("UpdateUsername", "Username updated successfully")
                }
                .addOnFailureListener { e ->
                    Log.e("UpdateUsername", "Failed to update username", e)
                }
        }
    }

    private fun showImageSourceDialog() {
        // Dialog to choose image source (camera or gallery)
        val items = arrayOf("Take Photo", "Choose from Gallery")
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Select Image Source")
        builder.setItems(items) { dialog, which ->
            when (which) {
                0 -> openCamera()
                1 -> openGallery()
            }
        }
        val dialog = builder.create()
        dialog.show()
    }

    private fun openCamera() {
        // Open camera to take a new photo
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        cameraLauncher.launch(takePictureIntent)
    }

    private fun openGallery() {
        // Open gallery to choose a photo
        val galleryIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        galleryLauncher.launch(galleryIntent)
    }

    companion object {
        private const val CAMERA_PERMISSION_CODE = 101
    }
}
